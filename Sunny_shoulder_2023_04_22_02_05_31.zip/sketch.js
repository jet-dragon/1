function setup() {
  createCanvas(400, 400);
  button=createButton('전체화면')
  button.position(0,0)
  button.mousePressed(goFullScreen)
}

function draw() {
  background(220);
}
function goFullScreen(){
  let Ps = fullscreen(400);
  fullscreen(Ps)
}
